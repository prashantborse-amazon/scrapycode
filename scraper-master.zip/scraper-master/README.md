# scraper

## Useful Commands

rm lambdaScraper/files/\*
cd scrapy-serverless/lambdaScraper/
python launcher.py

scrapy shell -s USER_AGENT='something-to-test' 'https://example.com'
