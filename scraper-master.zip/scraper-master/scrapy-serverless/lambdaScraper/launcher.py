import sys
import json

from lambdaScraper.crawl import crawl


def scrape(event={}, context={}):
    #crawl(start_urls='https://www.factset.com', allowed_domains='factset.com')
    crawl(start_urls=event["start_urls"], allowed_domains=event["allowed_domains"],
          s3_bucketname=event["s3_bucketname"])


if __name__ == "__main__":
    print (sys.argv[0])
    print (sys.argv[1])
    try:
        event = json.loads(sys.argv[1])
    except IndexError:
        event = {}
    print ("------------ event -------------", event)
    scrape(event)
