import tldextract

print (tldextract.extract('http://www.gta.net'))

ext = tldextract.extract('http://obrazovanie.1c.ru')

print (ext.domain +"." +ext.suffix)
