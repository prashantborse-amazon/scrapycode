import scrapy
import re
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
import os
from io import BytesIO
import boto3
from urllib.parse import urlparse
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError
from twisted.internet.error import TimeoutError, TCPTimedOutError

import time
import tldextract
import logging

from scrapy.utils.log import configure_logging

s3Client = boto3.client('s3')
# Versionning
__version__ = "0.1.0"

#logger = logging.getLogger('factsetlogger')

#configure_logging(install_root_handler = False)
#configure_logging({'filename':'Factset-logger.log','LOG_FORMAT': '%(levelname)s: %(message)s', 'level': 'logging.ERROR'})

logging.basicConfig(
    filename='Container-logger.log',
    format='%(asctime)s %(levelname)s: %(message)s',
    datefmt='%m/%d/%Y %I:%M:%S %p',
    level=logging.ERROR
)


class CrawlerSpider(CrawlSpider):
    name = 'crawler'

    def __init__(self, *args, **kwargs):
        # settings.overrides['DEPTH_LIMIT'] = 3
        #logger = logging.getLogger('scrapy.spidermiddlewares.httperror')
        logger = logging.getLogger()
        logger.setLevel(logging.ERROR)
        print ("logger.setLevel ---->", logger)

        super(CrawlerSpider, self).__init__(*args, **kwargs)

        # self.start_urls = kwargs.get('start_urls', '').split('|')
        # self.allowed_domains = kwargs.get('allowed_domains', '').split('|')
        self.s3 = boto3.client('s3')
        self.loadEnvironmentVars(**kwargs)
        self.loadUrls()

        self.folderexists = 0
        self.domainname = ''
        print ("self.folderexists = ", self.folderexists)

        print ("self.start_urls  ===>", self.start_urls)

        print ("self.allowed_domains  ===>", self.allowed_domains)
        #print ("self._connectTimeout = ", self._connectTimeout)



        # self.downloadfolder = os.path.join(kwargs.get('downloadfolder', 'c:\\temp\\downloads'),
        #                                    self.allowed_domains[0])
        # self.downloadfolder = os.path.join(os.path.join(os.getcwd(), "files"))
        # if not os.path.exists(self.downloadfolder):
        #     os.makedirs(self.downloadfolder)

    # linkextractor without filter gives us all the links
    rules = [Rule(LinkExtractor(), callback='download',
                  errback='errback_httpbin', follow=True)]

    handle_httpstatus_list = [301, 302]

    def download(self, response):
        # check if it's an html document
        if b'text/html' in response.headers.get('Content-Type', ''):
            # # unable to save file if filename length exceeds the limit
            filename = response.url.replace(
                "/", "__").replace(":", "!").replace("?", "_")
            # unable to save file if filename length exceeds the limit
            if len(filename) > 240:
                filename = filename[:240]

            #domainname = self.start_urls[0]
            #domainname = domainname.split("//")[1].split("/")[0]

            ext = tldextract.extract(response.url)
            domainname = ext.domain + "." + ext.suffix

            #print ("domainname = ", domainname)
            print ("response.url ---------->" , response.url)

            # if (self.folderexists == 0):
            #     print ("================ *********** =================")
            #     self.s3.put_object(Bucket=self.s3_bucketname, Body='', Key=(domainname + '/'))
            #     self.folderexists = 1
            #     print ("self.folderexists = ", self.folderexists)
            #     time.sleep(5)
            #     versioning = self.s3.BucketVersioning(Bucket=self.s3_bucketname, Key=(domainname + '/'))
            #     # check status
            #     print("versioning.status = ", versioning.status)
            #
            #     # enable versioning
            #     # versioning.enable()
            #     print ("================ *********** =================")

            print (is_in_aws(), " :: filename => ", filename)

            # print ("================ strt =================")
            # parsed_uri = urlparse(response.url)
            # domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
            # print ("domain     = ", domain)
            # print ("================ end =================")

            # write file
            if is_in_aws():
                self.s3.put_object(Bucket=self.s3_bucketname, Body='', Key=(domainname + '/'))
                filename = domainname + '/' + filename
                self.writeToS3(response, filename)
                print(f'Downloading url {response.url} to S3: {filename}')
            else:
                if not os.path.exists('lambdaScraper/files/' +domainname):
                    os.makedirs('lambdaScraper/files/' +domainname)
                filePath = os.path.join(
                    os.getcwd(), 'lambdaScraper/files/' +domainname, f'{filename}.html')
                with open(filePath, 'wb') as f:
                    f.write(response.body)
                    print(
                        f'Downloading url {response.url} to local:{filePath}')

    def writeToS3(self, response, filename):
        buf = BytesIO(response.body)
        self.s3.put_object(
            Body=buf, Bucket='pbfactset', Key=f'{filename}.html')

    def loadEnvironmentVars(self, **kwargs):
        self.S3HtmlBucket = os.getenv('S3_HTML_BUCKET', 'pbfactset')
        self.S3UrlFileBucket = os.getenv(
            'S3_URL_FILE_BUCKET', 'www.factset.com')
        self.S3UrlFileKey = os.getenv('S3_URL_FILE_KEY', 'urls.txt')

    def loadUrls(self):
        if is_in_aws():
            s3 = boto3.resource('s3')
            obj = s3.Object(self.S3UrlFileBucket, self.S3UrlFileKey)
            self.start_urls = obj.get()['Body'].read().decode(
                'utf-8').splitlines()
        else:
            with open(os.path.join(os.getcwd(), "lambdaScraper/spiders/urls.txt")) as f:
                self.start_urls = f.read().splitlines()
        allowedDomains = []
        for url in self.start_urls:
            ext = tldextract.extract(url)
            domainnames = ext.domain + "." + ext.suffix
            allowedDomains.append(domainnames)
            #allowedDomains.append(self.getHostName(url))
        self.allowed_domains = allowedDomains
        print("allowedDomains ===>", allowedDomains)
        print("self.start_urls ===>", self.start_urls)

    def getHostName(self, url):
        hostname = urlparse(url).hostname
        if hostname is None:
            print(f'No hostname for {url}')
        if hostname is not None and hostname.startswith('www.'):
            hostname = hostname.replace('www.', '')
        return hostname

    def errback_httpbin(self, failure):
        # log all failures
        self.logger.error(repr(failure))

        # in case you want to do something special for some errors,
        # you may need the failure's type:

        if failure.check(HttpError):
            # these exceptions come from HttpError spider middleware
            # you can get the non-200 response
            response = failure.value.response
            self.logger.error('HttpError on %s', response.url)

        elif failure.check(DNSLookupError):
            # this is the original request
            request = failure.request
            self.logger.error('DNSLookupError on %s', request.url)

        elif failure.check(TimeoutError, TCPTimedOutError):
            request = failure.request
            self.logger.error('TimeoutError on %s', request.url)

    def process_exception(self, request, exception, spider):
        self.logger.error('Scrapy Error: TimeoutError on %s', request.url)


def is_in_aws():
    #print (" *********************************  AWS_EXECUTION_ENV     found  *********************************")
    return os.getenv('AWS_EXECUTION_ENV') is not None
