import sys
import imp
import os
import logging
from urllib.parse import urlparse

from scrapy.spiderloader import SpiderLoader
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings

# Need to "mock" sqlite for the process to not crash in AWS Lambda / Amazon Linux
sys.modules["sqlite"] = imp.new_module("sqlite")
sys.modules["sqlite3.dbapi2"] = imp.new_module("sqlite.dbapi2")


def is_in_aws():
    return os.getenv('AWS_EXECUTION_ENV') is not None


def crawl(**spider_kwargs):
    spiderName = "crawler"
    settings = {}
    project_settings = get_project_settings()
    spiderLoader = SpiderLoader(project_settings)

    spider_cls = spiderLoader.load(spiderName)

    # feed_uri = ""
    # feed_format = "json"

    try:
        spider_key = urlparse(spider_kwargs.get("start_urls")[0]).hostname if spider_kwargs.get(
            "start_urls") else urlparse(spider_cls.start_urls[0]).hostname
    except Exception:
        logging.exception("Spider or kwargs need start_urls.")

    if is_in_aws():
        # Lambda can only write to the /tmp folder.
        settings['HTTPCACHE_DIR'] = "/tmp"
    # else:
    #     feed_uri = "file://{}/%(name)s-{}-%(time)s.json".format(
    #         os.path.join(os.getcwd(), "feed"),
    #         spider_key,
    #     )

    # settings['FEED_URI'] = feed_uri
    # settings['FEED_FORMAT'] = feed_format

    # set depth limit parameter here
    settings['DEPTH_LIMIT'] = 3

    os.environ["AWS_ACCESS_KEY_ID"] = project_settings.get('AWS_ACCESS_KEY_ID')
    os.environ["AWS_SECRET_ACCESS_KEY"] = project_settings.get('AWS_SECRET_ACCESS_KEY')

    os.environ["AWS_EXECUTION_ENV"] = 'y'
    os.environ["S3_HTML_BUCKET"] = 'pbfactset'
    os.environ["S3_URL_FILE_BUCKET"] = 'factset-scrapy-url-load'
    os.environ["S3_URL_FILE_KEY"] = 'urls.txt'

    print ("environment AWS_ACCESS_KEY_ID =>", os.getenv('AWS_ACCESS_KEY_ID'))
    print ("environment AWS_SECRET_ACCESS_KEY =>", os.getenv('AWS_SECRET_ACCESS_KEY'))

    print ("environment AWS_EXECUTION_ENV =>", os.getenv('AWS_EXECUTION_ENV'))
    print ("environment S3_HTML_BUCKET =>", os.getenv('S3_HTML_BUCKET'))
    print ("environment S3_URL_FILE_BUCKET =>", os.getenv('S3_URL_FILE_BUCKET'))
    print ("environment S3_URL_FILE_KEY =>", os.getenv('S3_URL_FILE_KEY'))

    process = CrawlerProcess({**project_settings, **settings})

    process.crawl(spider_cls, **spider_kwargs)
    process.start()
