# Scrapy settings for lambdaScraper project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://docs.scrapy.org/en/latest/topics/settings.html
#     https://docs.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://docs.scrapy.org/en/latest/topics/spider-middleware.html

BOT_NAME = 'lambdaScraper'

SPIDER_MODULES = ['lambdaScraper.spiders']
NEWSPIDER_MODULE = 'lambdaScraper.spiders'


# Crawl responsibly by identifying yourself (and your website) on the user-agent
USER_AGENT = 'krzaksa (+https://www.factset.com)'
# Obey robots.txt rules

ROBOTSTXT_OBEY = True
# Configure maximum concurrent requests performed by Scrapy (default: 16)
CONCURRENT_REQUESTS = 32

#DEPTH
DEPTH_LIMIT = 3

# SPIDER_MIDDLEWARES: {
#     "patchfinder.middlewares.DepthResetMiddleware": 850
# }

CONCURRENT_REQUESTS_PER_DOMAIN = 16
CONCURRENT_REQUESTS_PER_IP = 16

#priority BFS
DEPTH_PRIORITY = 1
DOWNLOAD_TIMEOUT=30

RETRY_ENABLED = False
RETRY_TIMES = 1

DEPTH_STATS_VERBOSE = True
AUTOTHROTTLE_ENABLED = True

#abhilas
#HTTPCACHE_ENABLED = True
#HTTPCACHE_ALWAYS_STORE = True

REDIRECT_MAX_TIMES = 1

AWS_ACCESS_KEY_ID = 'AKIAIWISYXT3FNS3O7UA'
AWS_SECRET_ACCESS_KEY = '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'

