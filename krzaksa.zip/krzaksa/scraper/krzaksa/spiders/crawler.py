#-*- coding: utf-8 -*-
import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
import os

# Versionning
__version__ = "0.1.0"

class CrawlerSpider(CrawlSpider):
    name = 'crawler'
    def __init__(self, *args, **kwargs):
        """
        simple init to set the default variables
        """
        super(CrawlerSpider, self).__init__(*args, **kwargs)
        # we may get multiple start urls and allowed domains '|' seperated
        self.start_urls = kwargs.get('start_urls','').split('|')
        self.allowed_domains = kwargs.get('allowed_domains', '').split('|')
        self.downloadfolder = os.path.join(kwargs.get('downloadfolder', 'c:\\temp\\downloads'),
                                        self.allowed_domains[0])
        if not os.path.exists(self.downloadfolder):
            os.makedirs(self.downloadfolder)
    # linkextractor without filter gives us all the links
    rules = [Rule(LinkExtractor(), callback = 'download', follow = True)]

    def download(self, response):
        """
        Save the html files only
        """
        # check if it's an html document
        if b'text/html' in response.headers.get('Content-Type',''):
            filename = response.url.replace("/","$").replace(":","!").replace("?","_")
            # unable to save file if filename length exceeds the limit
            if len(filename)>100 :
                filename = filename[:99]
            # Write the response body to a file
            print(f'{filename}.html')
            with open(os.path.join(self.downloadfolder, f'{filename}.html'), 'wb') as d_file:
                d_file.write(response.body)
