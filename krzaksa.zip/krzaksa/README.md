# krzaksa

This is a Scrapy project to crawl through all the webpages and save them locally.


## Downloaded files 

Downloaded files would be saved to the path provided in the arguments


## Downloader

This project contains one cralwer and you can list them using the `list`
command:

    $ scrapy list
    crawler
    


## Running the downloader

You can run the crawler using the `scrapy crawl` command, such as:

    $ scrapy crawl crawler -a start_urls="<url>" -a allowed_domains="<domainname.com>" --logfile <logile>
