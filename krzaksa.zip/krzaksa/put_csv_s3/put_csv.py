import json
import uuid 
import boto3

s3 = boto3.resource('s3')
ssm = boto3.client('ssm')

def alb_api(handler):
    """
    **Decorator**
    Converts the event from ALB into a more workable format
    Also converts the result to as accepted by ALB
    """

    def execute_handler(event):
        """
        Executes the handler
        """
        request = {}
        try:
            request["query_params"] = event["queryStringParameters"]
            request["body"] = json.loads(event["body"])

            status = 200
        
            result = handler(request)
        except KeyError as e:
            print(e)
            status = 400
            result = f"Missing parameter {str(e)}"
        except ValueError as e:
            print(e)
            status = 400
            result = "Faulty request"
        except Exception as e:
            print(e)
            status = 500
            result = "Something went wrong"
        
        return {
                "statusCode": status,
                "isBase64Encoded": False,
                "headers": {
                    "Content-Type": "text/html"
                },
                "body": result
            }
    
    return execute_handler

@alb_api      
def create_csv(event):
    url = event["body"]["url"] 
    depth = int(event["body"].get("depth", 3))
    
    #domains = event["body"]["domains"]

    # get bucket from parameter store
    url_bucket = ssm.get_parameter(
        Name='s3_url_bucket',
        WithDecryption=False)["Parameter"]["Value"]

    s3.Object(url_bucket, f'{uuid.uuid4()}_{depth}.csv').put(Body = f'{url}') # putting results as a csv file in S3

    return "Successfully posted the request"    

def lambda_handler(event, context):
    return create_csv(event)
    
